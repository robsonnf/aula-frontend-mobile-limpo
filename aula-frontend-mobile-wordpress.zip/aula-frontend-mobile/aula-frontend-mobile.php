<?php
/**
 * Plugin Name: Aula Frontend Mobile - Curso do Aluno
 * Description: Publica as 22 aulas interativas em uma página WordPress usando [afmc_curso].
 * Version: 1.0.0
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: Robson
 * Text Domain: aula-frontend-mobile
 */

defined( 'ABSPATH' ) || exit;

function afmc_course_url() {
    return plugins_url( 'student/index.html', __FILE__ );
}

function afmc_course_shortcode() {
    $url = afmc_course_url();
    // Inline layout keeps the viewer usable even when a theme renders shortcodes after wp_head.
    return '<section class="afmc-course" aria-label="Curso Desenvolvimento Web Mobile">'
        . '<p><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">'
        . 'Abrir curso em tela inteira (nova aba)</a></p>'
        . '<iframe src="' . esc_url( $url ) . '" title="Desenvolvimento Web Mobile: 22 aulas interativas" '
        . 'style="display:block;width:100%;height:85vh;min-height:420px;border:1px solid #ddd8cd;border-radius:8px;background:#fdfcf9" '
        . 'allow="fullscreen" allowfullscreen loading="eager"></iframe>'
        . '<p>Os exercícios de código são salvos neste navegador. Não há envio de notas ao professor.</p>'
        . '</section>';
}
add_shortcode( 'afmc_curso', 'afmc_course_shortcode' );

function afmc_admin_menu() {
    add_management_page( 'Curso do Aluno', 'Curso do Aluno', 'manage_options', 'afmc-course', 'afmc_admin_screen' );
}
add_action( 'admin_menu', 'afmc_admin_menu' );

function afmc_existing_page() {
    $id = (int) get_option( 'afmc_course_page_id', 0 );
    if ( $id <= 0 ) {
        return null;
    }
    $page = get_post( $id );
    return $page && 'page' === $page->post_type && 'trash' !== $page->post_status ? $page : null;
}

function afmc_admin_screen() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $page = afmc_existing_page();
    ?>
    <div class="wrap">
        <h1>Curso do Aluno: Desenvolvimento Web Mobile</h1>
        <p>22 aulas em português, com navegação, demonstrações e editores de código.</p>
        <p>O curso usa uma cópia independente dos arquivos do aluno. O projeto original permanece intacto.</p>
        <h2>1. Criar a página</h2>
        <?php if ( $page ) : ?>
            <p>A página já existe. Não será criada outra cópia.</p>
            <p><a class="button button-primary" href="<?php echo esc_url( get_edit_post_link( $page->ID, 'raw' ) ); ?>">Editar / publicar página</a></p>
        <?php else : ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="afmc_create_page">
                <?php wp_nonce_field( 'afmc_create_page' ); ?>
                <?php submit_button( 'Criar página em rascunho' ); ?>
            </form>
        <?php endif; ?>
        <h2>2. Revisar e publicar</h2>
        <p>Abra a prévia da página e teste uma aula. Depois clique em Publicar no editor do WordPress.</p>
        <p>Para mostrar o curso em outra página, insira um bloco Shortcode com <code>[afmc_curso]</code>.</p>
        <h2>O que esta versão faz</h2>
        <ul>
            <li>Preserva o visual e as interações do site estático dentro de uma página do WordPress.</li>
            <li>Oferece um link para estudar em tela inteira, sem o cabeçalho do tema.</li>
            <li>As aulas ficam no pacote, não são posts editáveis no editor de blocos.</li>
            <li>É um curso público: os arquivos podem ser acessados diretamente, mesmo com a página em rascunho ou protegida por senha.</li>
            <li>Não inclui matrícula, autenticação de alunos, certificados ou registro de notas.</li>
            <li>O editor avançado usa esm.sh. Sem acesso à rede, o editor simples continua disponível.</li>
        </ul>
        <p><a href="<?php echo esc_url( afmc_course_url() ); ?>" target="_blank" rel="noopener noreferrer">Abrir os arquivos do curso</a></p>
    </div>
    <?php
}

function afmc_create_page() {
    if ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
        wp_die( 'Use o formulário para criar a página.', '', array( 'response' => 405 ) );
    }
    if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'edit_pages' ) ) {
        wp_die( 'Você não tem permissão para criar esta página.', '', array( 'response' => 403 ) );
    }
    check_admin_referer( 'afmc_create_page' );
    if ( ! afmc_existing_page() ) {
        $id = wp_insert_post(
            array(
                'post_type'    => 'page',
                'post_status'  => 'draft',
                'post_title'   => 'Desenvolvimento Web Mobile',
                'post_name'    => 'curso-frontend-mobile',
                'post_content'=> '<!-- wp:shortcode -->[afmc_curso]<!-- /wp:shortcode -->',
            ),
            true
        );
        if ( is_wp_error( $id ) ) {
            wp_die( esc_html( $id->get_error_message() ) );
        }
        update_option( 'afmc_course_page_id', (int) $id, false );
    }
    wp_safe_redirect( admin_url( 'tools.php?page=afmc-course' ) );
    exit;
}
add_action( 'admin_post_afmc_create_page', 'afmc_create_page' );
